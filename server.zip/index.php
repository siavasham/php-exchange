
<?php

include __DIR__.'/public/index.php';