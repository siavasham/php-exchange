@extends('layouts.app')

@section('content')

   
    @include('section.header')
    @include('section.service')
    @include('section.coins')
    @include('section.trading')
    @include('section.news')
   

@endsection
