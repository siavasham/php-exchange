<?php

return [

    'emailVerification'=>'Email Verification',
    'verfyYourEmail'=>'Confirm your email',
    'singUpTnx'=>'Thank you for your membership',
    'thanks'=>'Thanks',
    'verificationCode'=>'Your activation code '
];