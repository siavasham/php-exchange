<?php

return [
    'brand'=>'concordex',
    'academy'=>'آکادمی ارزدیجیتال',
    'info'=>'نکات کوتاه',
    'ask-question'=>'سوالی دارید؟ همینجا بپرسید',
    'search-placeholder'=>'گفتگو با پشتیبانی آنلاین سایت...',
    'read-more'=>'بیشتر بدانید',
    'crypto-glance'=>'وضعیت ارزهای دیجیتال در یک نگاه',
    'crypto-btn'=>'نمایش کامل' ,
    'our-balance'=>'موجودی ما'
];