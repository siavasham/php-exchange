<?php

return [

    'emailVerification'=>'تایید ایمیل',
    'verfyYourEmail'=>'ایمل خود را تایید کنید',
    'singUpTnx'=>'از عضویت شما متشکریم ',
    'thanks'=>'با تشکر',
    'verificationCode'=>'کد فعال سازی شما'
];