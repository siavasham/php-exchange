<?php 

namespace App\Library;

class Notifications {
    public function __construct() {
        return "construct function was initialized.";
    }

    public function create() {
        // create notification
        // send email
        // return output
    }
}