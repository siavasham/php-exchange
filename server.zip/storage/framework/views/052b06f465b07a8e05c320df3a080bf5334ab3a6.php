<div class="row trading">
    <div class="col-sm-12 col-md-5 mb-4 trading-desc">
        <h3 class="title pb-3"><?php echo e($constans->kycTrading); ?> </h3>
        <div class="desc pb-3"><?php echo e($constans->kycTradingDesc); ?> </div>
        <button type="button" class="btn btn-outline-danger btn-trade"><?php echo e($constans->kycTradingBtn); ?></button>
    </div>
    <div class="col-sm-12 col-md-7  trade-items">
        <?php for($i = 1; $i < 7; $i++): ?>
            <div class="trade-item">
                <div class="trade-counter">
                    <?php echo e($i); ?>

                </div>
                <div class="trade-text">
                    <?php echo e($constans->{'kyc'.$i}); ?>

                </div>
            </div>
        <?php endfor; ?>  
    </div>
</div>
<div class="row safe">
    <div class="col-sm-12 col-md-5 mb-4 safe-desc">
        <h3 class="title pb-3"><?php echo e($constans->safeTitle); ?> </h3>
        <div class="desc pb-3"><?php echo e($constans->safeDesc); ?> </div>
    </div>
    <div class="col-sm-12 col-md-7 h-100">
        <div class="row">
        <?php for($i = 1; $i < 7; $i++): ?>
            <div class="safe-item col-4">
                <img src="<?php echo e(asset('/img/'.(in_array($i,[2,5])?'tick':'trust').'.svg')); ?>" />
                <?php echo e($constans->{'safe'.$i}); ?>

            </div>
        <?php endfor; ?>  
        </div>
    </div>
  </div><?php /**PATH D:\asadzade\exchange\resources\views/section/trading.blade.php ENDPATH**/ ?>