<div class="row">
  <div class="col-12">
    <div class="coins cf">
      <div class="courses cf" id="showcase">
      <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="course-item slide">
          <div class="course-summary coin-card">
            <div class="course-thumbnail">
            <img src="<?php echo e(asset('/crypto/'.strtolower($slider->name).'.svg')); ?>" />
            </div>
            <div class="course-info">
              <h6 class="course-title"><?php echo e($slider->dname ? $slider->dname : $slider->fullname); ?></h6>
              <span class="course-price"><?php echo e($slider->price); ?></span>
            </div>
            <div class="course-balance">
              <?php echo e(__('home.our-balance')); ?> : <span><?php echo e($slider->balance); ?></span>
            </div>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\asadzade\exchange\resources\views/section/coins.blade.php ENDPATH**/ ?>