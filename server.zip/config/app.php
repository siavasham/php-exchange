<?php

return [
    'locale' => 'fa',
    
];